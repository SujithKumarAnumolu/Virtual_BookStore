import React, { createContext, useState, useEffect, useContext } from 'react';
import Cookies from 'js-cookie';
import { useAuth } from './AuthContext';

export const CartContext = createContext();
export const useCart = () => useContext(CartContext);

export function CartProvider({ children }) {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState([]);
  const [isUserReady, setIsUserReady] = useState(false);

  // Wait for user to hydrate from localStorage
  useEffect(() => {
    if (user !== undefined) {
      setIsUserReady(true);
    }
  }, [user]);

  // Load cart from cookie only after when user is ready
  useEffect(() => {
    if (!isUserReady || !user?.email) return;

    const cookieCart = Cookies.get(`cart-${user.email}`);
    if (cookieCart) {
      try {
        setCartItems(JSON.parse(cookieCart));
      } catch {
        setCartItems([]);
      }
    } else {
      setCartItems([]);
    }
  }, [isUserReady, user?.email]);

  // Save the cart to cookies
  useEffect(() => {
    if (isUserReady && user?.email) {
      Cookies.set(`cart-${user.email}`, JSON.stringify(cartItems), { expires: 7 });
    }
  }, [cartItems, user?.email, isUserReady]);

  const addToCart = (book) => {
    if (!user?.email) return;
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === book.id);
      if (existing) {
        return prev.map((item) =>
          item.id === book.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...book, quantity: 1 }];
    });
  };

  const updateQuantity = (id, quantity) => {
    if (!user?.email) return;
    setCartItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantity: quantity > 0 ? quantity : 1 } : item
      )
    );
  };

  const removeFromCart = (id) => {
    if (!user?.email) return;
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const clearCart = () => {
    if (!user?.email) return;
    setCartItems([]);
    Cookies.remove(`cart-${user.email}`);
  };

  const resetCart = () => {
    setCartItems([]);
  };

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      updateQuantity,
      removeFromCart,
      clearCart,
      resetCart
    }}>
      {children}
    </CartContext.Provider>
  );
}
