import axios from 'axios';

const BASE_URL = '/api/orders';

export const getUserOrders = (email) => axios.get(`/api/orders/user/${email}`);

export const getAllOrders = () => axios.get(BASE_URL);

export const updateOrderStatus = (orderId, status) =>
  axios.put(`${BASE_URL}/${orderId}/status`, status, {
    headers: { 'Content-Type': 'text/plain' }
  });

export const placeOrder = async (order) => {
  const token = localStorage.getItem('token');
  const response = await axios.post(
    'http://localhost:8080/api/orders',
    order,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    }
  );
  return response.data;
};

