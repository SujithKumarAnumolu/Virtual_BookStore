import axios from '../config/axiosConfig';

const BASE_USER_URL = '/api/books';     // for user/public
const BASE_ADMIN_URL = '/api/admin/books';  // for admin

// User Functions for normal users
export const fetchAllBooks = () => axios.get(BASE_USER_URL);
export const fetchBookById = (id) => axios.get(`${BASE_USER_URL}/${id}`);
export const searchBooks = (query) => axios.get(`${BASE_USER_URL}/search?title=${query}`);
export const fetchBooksByGenre = (genre) => axios.get(`/api/books/genre/${genre}`);
  

// Admin Functions for only admin
export const getAllBooksAdmin = () => axios.get(BASE_ADMIN_URL);
export const addBook = (bookData) => axios.post(BASE_ADMIN_URL, bookData);
export const updateBook = (id, bookData) => axios.put(`${BASE_ADMIN_URL}/${id}`, bookData);
export const deleteBook = (id) => axios.delete(`${BASE_ADMIN_URL}/${id}`);
