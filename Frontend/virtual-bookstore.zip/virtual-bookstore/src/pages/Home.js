import React, { useEffect, useState } from 'react';
import { fetchBooksByGenre } from '../services/bookService';
import { useNavigate } from 'react-router-dom';
import './HomePage.css';
//background posters for home page
const backgroundPosters = [
  '/images/banner1.jpg',
  '/images/banner2.jpg',
  '/images/banner3.jpg',
];

const genresToDisplay = ['Classic', 'Dystopian', 'Fantasy'];

const HomePage = () => {
  const [genreBooks, setGenreBooks] = useState({});
  const [currentIndex, setCurrentIndex] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const promises = genresToDisplay.map((genre) => fetchBooksByGenre(genre));
      const responses = await Promise.all(promises);
      const booksByGenre = {};
      const defaultIndex = {};
      genresToDisplay.forEach((genre, i) => {
        booksByGenre[genre] = responses[i].data.slice(0, 5);
        defaultIndex[genre] = 0;
      });
      setGenreBooks(booksByGenre);
      setCurrentIndex(defaultIndex);
    };

    fetchData();
  }, []);

  // Autoloop per genre
  useEffect(() => {
    const intervals = {};
    genresToDisplay.forEach((genre) => {
      intervals[genre] = setInterval(() => {
        setCurrentIndex((prev) => ({
          ...prev,
          [genre]: genreBooks[genre]
            ? (prev[genre] + 1) % genreBooks[genre].length
            : 0,
        }));
      }, 4000);
    });

    return () => Object.values(intervals).forEach(clearInterval);
  }, [genreBooks]);

  const handleImageClick = (id) => {
    navigate(`/book/${id}`);
  };

  const handleBannerClick = () => {
    navigate('/books');
  };

  return (
    <div className="homepage-container">
      {/* Clickable banner area so that it will navigate to list of books */}
      <div className="banner-wrapper" onClick={handleBannerClick} style={{ cursor: 'pointer' }}>
        <div className="background-slider">
          {backgroundPosters.map((src, index) => (
            <img key={index} src={src} alt={`Banner ${index + 1}`} className="background-img" />
          ))}
        </div>
        <div className="welcome-overlay">
          <h1>📚 Welcome to <span className="highlight">Virtual Bookstore</span></h1>
          <p>Discover, explore, and shop from a collection of top-rated books — with in-store pickup or delivery!</p>
        </div>
      </div>

      {/* Genre Sections in a row */}
      <h2 className="featured-heading">📖 Discover by Genre</h2>
      <div className="genre-row">
        {genresToDisplay.map((genre) => (
          <div key={genre} className="genre-section">
            <h3 className="genre-title">{genre}</h3>
            <div className="genre-card">
              {genreBooks[genre] && (
                <div className="book-card">
                  <img
                    src={genreBooks[genre][currentIndex[genre]]?.imageUrl || 'https://via.placeholder.com/200x300'}
                    alt={genreBooks[genre][currentIndex[genre]]?.title}
                    className="book-image"
                    onClick={() => handleImageClick(genreBooks[genre][currentIndex[genre]]?.id)}
                  />
                  <h4 className="book-title">{genreBooks[genre][currentIndex[genre]]?.title}</h4>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomePage;
