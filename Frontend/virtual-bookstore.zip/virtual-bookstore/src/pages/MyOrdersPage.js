import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getUserOrders } from '../services/orderService';
import './MyOrdersPage.css';

const MyOrdersPage = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        if (user?.email) {
          const response = await getUserOrders(user.email); //calls the API
          setOrders(response.data);
        }
      } catch (error) {
        console.error('Error fetching user orders:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [user]);

  if (!user) {
    return <h2 className="orders-container">Please log in to view your orders.</h2>;
  }

  if (loading) {
    return <h2 className="orders-container">Loading your orders...</h2>;
  }

  if (orders.length === 0) {
    return <h2 className="orders-container">🛒 You have no orders yet!</h2>;
  }

  return (
    <div className="orders-container">
      <h2>📦 My Orders</h2>

      {orders.map((order, index) => (
        <div key={order.id} className="order-card">
          <h3>Order #{order.id}</h3>

          <p><strong>Shipping Method:</strong> {order.shippingMethod}</p>
          <p><strong>Payment Method:</strong> {order.paymentMethod}</p>
          <p><strong>Order Date:</strong> {new Date(order.createdAt).toLocaleString()}</p>
          <p><strong>Last Updated:</strong> {new Date(order.updatedAt || order.createdAt).toLocaleString()}</p>
          <p><strong>Order Status:</strong> {order.status}</p>

          <table className="order-items-table">
            <thead>
              <tr>
                <th>Book</th>
                <th>Quantity</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((item, idx) => (
                <tr key={idx}>
                  <td>{item.title}</td>
                  <td>{item.quantity}</td>
                  <td>${item.price}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="order-summary">
            <p>Subtotal: ${order.subtotal.toFixed(2)}</p>
            <p>Tax (5%): ${order.tax.toFixed(2)}</p>
            <p>Shipping: ${order.shippingCost.toFixed(2)}</p>
            <p><strong>Total: ${order.total.toFixed(2)}</strong></p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MyOrdersPage;
