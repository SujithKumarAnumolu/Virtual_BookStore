import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { CartContext } from '../contexts/CartContext';
import './CartPage.css';

function CartPage() {
    const { cartItems, updateQuantity, removeFromCart } = useContext(CartContext);
    const navigate = useNavigate(); // to Initialize navigate

    const getTotalPrice = () =>
        cartItems.reduce((total, item) => total + item.price * item.quantity, 0);

    const handleCheckout = () => {
        if (cartItems.length === 0) {
            alert('Cart is empty!');
            return;
        }
        console.log('Proceeding to checkout...');
        navigate('/checkout'); // To Redirect Checkout page
    };

    if (cartItems.length === 0) {
        return <h2 className="empty-cart">🛒 Your cart is empty!</h2>;
    }

    return (
        <div className="cart-container">
            <h2>Your Shopping Cart</h2>
            <table className="cart-table">
                <thead>
                    <tr>
                        <th>Book</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {cartItems.map((item) => (
                        <tr key={item.id}>
                            <td className="cart-book-info">
                                <img
                                    src={item.imageUrl || "https://via.placeholder.com/100x140?text=No+Image"}
                                    alt={item.title}
                                    className="cart-book-image"
                                />
                                <span>{item.title}</span>
                            </td>
                            <td>${item.price}</td>
                            <td>
                                <input
                                    type="number"
                                    min="1"
                                    value={item.quantity}
                                    onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                                    className="quantity-input"
                                />
                            </td>
                            <td>₹{item.price * item.quantity}</td>
                            <td>
                                <button
                                    onClick={() => removeFromCart(item.id)}
                                    className="remove-button"
                                >
                                    Remove
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div className="cart-total">
                <h3>Grand Total: ${getTotalPrice()}</h3>

                {/* Cart Checkout Button */}
                <button className="checkout-button" onClick={handleCheckout}>
                    Proceed to Checkout
                </button>
            </div>
        </div>
    );
}

export default CartPage;
