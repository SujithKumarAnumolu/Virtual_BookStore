import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
import './ProfilePage.css';

const ProfilePage = () => {
  const { user, login } = useAuth();
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    password: '',
    address: '',
    role: 'USER'
  });
  useEffect(() => {
    if (user) {
        setProfile({
            name: user.name,
            email: user.email,
            password: '',
            address: user.address || '',
            role: user.role
          });
          
    }
  }, [user]);

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      await axios.put('/api/auth/update-profile', profile);
      alert('✅ Profile updated successfully!');

      // Refresh context if name is changed
      login({ ...user, name: profile.name });

    } catch (error) {
      console.error('Error updating profile:', error);
      alert('❌ Failed to update profile.');
    }
  };

  if (!user) {
    return <h2 className="profile-container">Please log in to view your profile.</h2>;
  }

  return (
    <div className="profile-container">
      <h2>👤 My Profile</h2>

      <form className="profile-form" onSubmit={handleSave}>
        <label>Name:</label>
        <input
          type="text"
          name="name"
          value={profile.name}
          onChange={handleChange}
        />

        <label>Email:</label>
        <input
          type="email"
          name="email"
          value={profile.email}
          disabled
        />

        <label>Shipping Address:</label>
        <textarea
        name="address"
        value={profile.address}
        onChange={handleChange}
        rows="3"
        />

        <label>New Password:</label>
        <input
          type="password"
          name="password"
          placeholder="Leave empty to keep same password"
          value={profile.password}
          onChange={handleChange}
        />

        <button type="submit" className="save-button">Save Changes</button>
      </form>
    </div>
  );
};

export default ProfilePage;
