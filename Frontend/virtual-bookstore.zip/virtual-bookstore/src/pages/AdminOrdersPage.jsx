import React, { useEffect, useState } from 'react';
import { getAllOrders, updateOrderStatus } from '../services/orderService';
import './AdminOrdersPage.css';

const AdminOrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAllOrders()
      .then((res) => setOrders(res.data))
      .catch((err) => console.error('Error fetching orders:', err))
      .finally(() => setLoading(false));
  }, []);

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      await updateOrderStatus(orderId, newStatus);

      // Update state with new status and updatedAt
      setOrders((prevOrders) =>
        prevOrders.map((order) =>
          order.id === orderId
            ? { ...order, status: newStatus, updatedAt: new Date().toISOString() }
            : order
        )
      );
    } catch (error) {
      console.error('Failed to update order status:', error);
      alert('Failed to update status. Please try again.');
    }
  };

  if (loading) {
    return <h2 className="admin-orders-container">Loading orders...</h2>;
  }

  if (orders.length === 0) {
    return <h2 className="admin-orders-container">No orders placed yet.</h2>;
  }

  return (
    // To get the orders in the from of table
    <div className="admin-orders-container">
      <h2>📦 Admin Dashboard - Manage Orders</h2>
      <table className="admin-orders-table">
        <thead>
          <tr>
            <th>Book</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Payment</th>
            <th>Shipping</th>
            <th>Order Date</th>
            <th>Last Updated</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) =>
            order.items.map((item, idx) => (
              <tr key={`${order.id}-${idx}`}>
                <td>{item.title}</td>
                <td>{item.quantity}</td>
                <td>${item.price}</td>

                {idx === 0 && (
                  <>
                    <td rowSpan={order.items.length}>{order.paymentMethod}</td>
                    <td rowSpan={order.items.length}>{order.shippingMethod}</td>
                    <td rowSpan={order.items.length}>
                      {new Date(order.createdAt).toLocaleString()}
                    </td>
                    <td rowSpan={order.items.length}>
                      {new Date(order.updatedAt || order.createdAt).toLocaleString()}
                    </td>
                    <td rowSpan={order.items.length}>
                      <select
                        value={order.status}
                        onChange={(e) => handleStatusChange(order.id, e.target.value)}
                      >
                        
                        {order.shippingMethod === 'pickup' ? (
                            // admin can change the pickup status
                          <>
                            <option value="Pending">Pending</option>
                            <option value="Ready to Pickup">Ready to Pickup</option>
                            <option value="Picked Up">Picked Up</option>
                            <option value="Cancelled">Cancelled</option>
                          </>
                        ) : (
                            // admin can change the shipping status
                          <>
                            <option value="Pending">Pending</option>
                            <option value="Shipped">Shipped</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                          </>
                        )}
                      </select>
                    </td>
                  </>
                )}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default AdminOrdersPage;
