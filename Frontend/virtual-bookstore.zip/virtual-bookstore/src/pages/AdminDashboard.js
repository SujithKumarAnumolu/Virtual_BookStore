import React, { useEffect, useState } from 'react';
import { getAllBooksAdmin, addBook, updateBook, deleteBook } from '../services/bookService';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [books, setBooks] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    author: '',
    description: '',
    price: '',
    stock: '',
    genre: '',
    imageUrl: '',
    available: true
  });
  const [editingBookId, setEditingBookId] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadBooks();
  }, []);

  const loadBooks = async () => {
    try {
      const response = await getAllBooksAdmin();
      setBooks(response.data);
    } catch (error) {
      console.error('Failed to fetch books:', error);
      setMessage('Failed to load books. Please check the server and your permissions.');
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingBookId) {
        await updateBook(editingBookId, formData);
        setMessage('Book updated successfully!');
      } else {
        await addBook(formData);
        setMessage('Book added successfully!');
      }
      setFormData({
        title: '',
        author: '',
        description: '',
        price: '',
        stock: '',
        genre: '',
        imageUrl: '',
        available: true
      });
      setEditingBookId(null);
      loadBooks();
    } catch (error) {
      console.error('Error saving book:', error);
      setMessage('Something went wrong.');
    }
  };

  const handleEdit = (book) => {
    setFormData(book);
    setEditingBookId(book.id);
  };
  // to deleat a book
  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      try {
        await deleteBook(id);
        setMessage('Book deleted successfully!');
        loadBooks();
      } catch (error) {
        console.error('Error deleting book:', error);
        setMessage('Failed to delete book.');
      }
    }
  };

  return (
    <div className="admin-dashboard">
      <h2>📚 Admin Dashboard - Manage Books</h2>
      {message && <p className="admin-message">{message}</p>}
      {/* book edit form */}
      <form className="admin-form" onSubmit={handleSubmit}>
        <input name="title" value={formData.title} onChange={handleChange} placeholder="Title" required />
        <input name="author" value={formData.author} onChange={handleChange} placeholder="Author" required />
        <textarea name="description" value={formData.description} onChange={handleChange} placeholder="Description" required />
        <input name="price" type="number" value={formData.price} onChange={handleChange} placeholder="Price" required />
        <input name="stock" type="number" value={formData.stock} onChange={handleChange} placeholder="Stock" required />
        <input name="genre" value={formData.genre} onChange={handleChange} placeholder="Genre" />
        <input name="imageUrl" value={formData.imageUrl} onChange={handleChange} placeholder="Image URL" />
        <label>
          Available:
          <input type="checkbox" name="available" checked={formData.available} onChange={handleChange} />
        </label>
        <button type="submit">{editingBookId ? 'Update Book' : 'Add Book'}</button>
      </form>

      {/* Table view for all the book */}
      <table className="admin-book-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Price ($)</th>
            <th>Stock</th>
            <th>Genre</th>
            <th>Available</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {books.length === 0 ? (
            <tr>
              <td colSpan="7">No books available.</td>
            </tr>
          ) : (
            books.map((book) => (
              <tr key={book.id}>
                <td>{book.title}</td>
                <td>{book.author}</td>
                <td>${book.price}</td>
                <td>{book.stock}</td>
                <td>{book.genre}</td>
                <td>{book.available ? "✅" : "❌"}</td>
                <td>
                  <button onClick={() => handleEdit(book)}>✏️ Edit</button>
                  <button onClick={() => handleDelete(book.id)}>🗑️ Delete</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default AdminDashboard;
