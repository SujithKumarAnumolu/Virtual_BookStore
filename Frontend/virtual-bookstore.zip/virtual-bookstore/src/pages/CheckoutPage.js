import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { placeOrder } from '../services/orderService';
import './CheckoutPage.css';

const CheckoutPage = () => {
  const { cartItems, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [shipping, setShipping] = useState('pickup');
  const [paymentMethod, setPaymentMethod] = useState('paypal');
  const [orderStatus, setOrderStatus] = useState(null);
  const [creditCard, setCreditCard] = useState({
    name: '',
    number: '',
    expiry: '',
    cvv: ''
  });
  const [address, setAddress] = useState('');

  const getSubtotal = () => cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  const getTax = () => getSubtotal() * 0.05;
  const getShippingCost = () => {
    switch (shipping) {
      case 'standard': return 50;
      case 'expedited': return 100;
      default: return 0;
    }
  };
  const getTotal = () => getSubtotal() + getTax() + getShippingCost();

  useEffect(() => {
    if (shipping !== 'pickup') {
      setAddress(user?.address || '');
    } else {
      setAddress('');
    }
  }, [shipping, user]);

  const handleConfirmOrder = async () => {
    if (cartItems.length === 0) return alert('Your cart is empty!');
    if (shipping !== 'pickup' && !address.trim()) return alert('Please enter a shipping address.');
    if (paymentMethod === 'credit' && (!creditCard.name || !creditCard.number || !creditCard.expiry || !creditCard.cvv)) {
      return alert('Please fill all credit card details.');
    }

    const order = {
      userEmail: user.email,
      items: cartItems.map(item => ({ title: item.title, quantity: item.quantity, price: item.price })),
      shippingMethod: shipping,
      address: shipping === 'pickup' ? 'PICKUP - In Store' : address,
      paymentMethod,
      creditCard: paymentMethod === 'credit' ? creditCard : null,
      subtotal: getSubtotal(),
      tax: getTax(),
      shippingCost: getShippingCost(),
      total: getTotal(),
      status: 'Pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    try {
      await placeOrder(order);
      clearCart();
      setOrderStatus('success');
    } catch (err) {
      alert('Failed to place order.');
      console.error(err);
    }
  };

  if (orderStatus === 'success') {
    return (
      <div className="checkout-container">
        <h2>🎉 Order Confirmed!</h2>
        <p>Your order has been placed successfully.</p>
        <button className="checkout-button" onClick={() => navigate('/')}>
          Go to Home
        </button>
      </div>
    );
  }

  return (
    <div className="cart-container">
      <h2>Checkout Summary</h2>

      {/* Items Table */}
      <table className="cart-table">
        <thead>
          <tr>
            <th>Book</th><th>Price</th><th>Qty</th><th>Total</th>
          </tr>
        </thead>
        <tbody>
          {cartItems.map(item => (
            <tr key={item.id}>
              <td className="cart-book-info">
                <img src={item.imageUrl || "https://via.placeholder.com/100x140"} alt={item.title} className="cart-book-image" />
                <span>{item.title}</span>
              </td>
              <td>${item.price}</td>
              <td>{item.quantity}</td>
              <td>${item.price * item.quantity}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="cart-total">
        <p>Subtotal: ${getSubtotal().toFixed(2)}</p>
        <p>Tax: ${getTax().toFixed(2)}</p>
        <p>Shipping: ${getShippingCost().toFixed(2)}</p>
        <p><strong>Total: ${getTotal().toFixed(2)}</strong></p>
      </div>

      {/* Pic up or Shipping Method */}
      <div className="select-box">
        <label>Shipping Method:</label>
        <select value={shipping} onChange={(e) => setShipping(e.target.value)}>
          <option value="pickup">Pickup (Free)</option>
          <option value="standard">Standard ($50)</option>
          <option value="expedited">Expedited ($100)</option>
        </select>
      </div>

      {shipping !== 'pickup' && (
        <div className="input-with-icon">
        <span className="icon">🏠</span>
        <textarea
          className="address-textarea"
          rows="3"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Enter your shipping address"
        />
      </div>
      
      )}

      {/* Payment Mathod */}
      <div className="select-box">
        <label>Payment Method:</label>
        <select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
          <option value="paypal">PayPal</option>
          <option value="credit">Credit Card</option>
        </select>
      </div>

      {/* If payment method is Credit Card user need to fill the credit card details */}
      {paymentMethod === 'credit' && (
        <div className="credit-card-form">
          <div className="input-with-icon">
            <span className="icon">👤</span>
            <input
              type="text"
              placeholder="Cardholder Name"
              value={creditCard.name}
              onChange={(e) => setCreditCard({ ...creditCard, name: e.target.value })}
            />
          </div>
          <div className="input-with-icon">
            <span className="icon">💳</span>
            <input
              type="text"
              placeholder="Card Number"
              value={creditCard.number}
              onChange={(e) => setCreditCard({ ...creditCard, number: e.target.value })}
            />
          </div>
          <div className="flex-row">
            <div className="input-with-icon">
              <span className="icon">📅</span>
              <input
                type="text"
                placeholder="MM/YY"
                value={creditCard.expiry}
                onChange={(e) => setCreditCard({ ...creditCard, expiry: e.target.value })}
              />
            </div>
            <div className="input-with-icon">
              <span className="icon">🔒</span>
              <input
                type="text"
                placeholder="CVV"
                value={creditCard.cvv}
                onChange={(e) => setCreditCard({ ...creditCard, cvv: e.target.value })}
              />
            </div>
          </div>
        </div>
      )}

      <button className="checkout-button" onClick={handleConfirmOrder}>
        Confirm Order
      </button>
    </div>
  );
};

export default CheckoutPage;
