import React, { useState } from 'react';
import axios from 'axios';
import './LoginPage.css';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const LoginPage = () => {
  const [formData, setFormData] = useState({ email: '', password: '', role: 'USER' });
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const handleChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const response = await axios.post('/api/auth/login', formData);
      login(response.data); // Saves the user in context

      const userRole = response.data.role;

      if (userRole === 'ADMIN') {
        navigate('/admin-dashboard'); // Redirect Admins to Admin Dashboard page
      } else {
        navigate('/'); // Redirect normal Users to Home page
      }

    } catch (error) {
      setErrorMessage('Login failed. Please check your credentials.');
      console.error('Login error:', error.response?.data || error.message);
    }
  };

  return (
    <div className="login-page">
      <h2>Login</h2>
      {location.state?.message && <p className="info-message">{location.state.message}</p>}
      {errorMessage && <p className="error-message">{errorMessage}</p>}
      <form onSubmit={handleSubmit}>
        <input
          name="email"
          type="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
          required
        />
        <input
          name="password"
          type="password"
          placeholder="Password"
          value={formData.password}
          onChange={handleChange}
          required
        />
        <select
          name="role"
          value={formData.role}
          onChange={handleChange}
          required
        >
          <option value="USER">User</option>
          <option value="ADMIN">Admin</option>
        </select>
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default LoginPage;
