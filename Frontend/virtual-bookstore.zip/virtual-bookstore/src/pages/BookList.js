import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import axios from 'axios';
import './BookListPage.css';

function BookList() {
    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const location = useLocation();
    const query = new URLSearchParams(location.search).get('query');

    useEffect(() => {
        const fetchBooks = async () => {
            try {
                const response = query
                    ? await axios.get(`http://localhost:8080/api/books/search?title=${query}`)
                    : await axios.get('http://localhost:8080/api/books');
                setBooks(response.data);
            } catch (error) {
                console.error('Error fetching books:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchBooks();
    }, [query]);

    if (loading) return <p>Loading books...</p>;
    // it will return all available books and return with below book grid
    return (
        <div className="booklist-container">
            <h2>{query ? `Search Results for "${query}"` : 'Available Books'}</h2>
            {books.length === 0 ? (
                <p>No books found.</p>
            ) : (
                <div className="book-grid">
                    {books.map((book) => (
                        <div key={book.id} className="book-card">
                            <img
                                src={book.imageUrl || "https://via.placeholder.com/200x300?text=No+Image"}
                                alt={book.title}
                                className="book-image"
                            />
                            <div className="book-info">
                                <h3 className="book-title">{book.title}</h3>
                                <div className="book-price">${book.price}</div>
                                <Link to={`/book/${book.id}`}>
                                    <button className="view-details-button">View Details</button>
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default BookList;
