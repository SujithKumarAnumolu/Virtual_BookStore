import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { CartContext } from '../contexts/CartContext'; //Import the CartContext
import { useContext } from 'react';
import axios from 'axios';
import './BookDetailPage.css';

function BookDetailPage() {
    const { id } = useParams();
    const { addToCart } = useContext(CartContext);//it will use CartContext to upadte the cart
    const [book, setBook] = useState(null);

    useEffect(() => {
        axios.get(`http://localhost:8080/api/books/${id}`)
            .then(response => setBook(response.data))
            .catch(error => console.error("Error fetching book:", error));
    }, [id]);

    if (!book) return <p>Loading book details...</p>;

    const handleAddToCart = () => {
        addToCart(book);
        alert(`${book.title} added to your cart!`);
    };

    return (
        <div className="book-detail-container">
            <img
                src={book.imageUrl || "https://via.placeholder.com/400x600?text=No+Image"}
                alt={book.title}
                className="book-detail-image"
            />
            <div className="book-detail-info">
                <h1>{book.title}</h1>
                <h3>by {book.author}</h3>
                <p><strong>Genre:</strong> {book.genre}</p>
                <p><strong>Price:</strong> ${book.price}</p>
                <p>{book.description}</p>

                <p>
                    <strong>Availability:</strong>
                    <span className={`badge ${book.available ? 'available' : 'outofstock'}`}>
                        {book.available ? "In Stock" : "Out of Stock"}
                    </span>
                </p>

                <button
                    className="add-to-cart-button"
                    onClick={handleAddToCart}
                    disabled={!book.available}
                >
                    {book.available ? "Add to Cart" : "Out of Stock"}
                </button>
            </div>
        </div>
    );
}

export default BookDetailPage;
