import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from './pages/Home';
import BookList from './pages/BookList';
import BookDetail from './pages/BookDetail';
import Cart from './pages/Cart';
import Toggle from "./components/Toggle";
import Navbar from "./components/Navbar";
import AdminNavbar from "./components/AdminNavbar";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import ProtectedRoute from "./components/ProtectedRoute";
import AdminDashboard from "./pages/AdminDashboard";
import AdminOrdersPage from './pages/AdminOrdersPage';
import CheckoutPage from './pages/CheckoutPage';
import MyOrdersPage from './pages/MyOrdersPage';
import ProfilePage from './pages/ProfilePage';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

function AppContent() {
  const { user } = useAuth();

  const isAdmin = user?.role === "ADMIN"; // checking role in uppercase- in the DB the role for admin should be uppercase

  return (
    <>
      {/* Conditionally render Navbar */}
      {isAdmin ? <AdminNavbar /> : <Navbar />}

      <Routes>
        {/* Public Routes for login & Signup */}
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        
        {/* Protected Routes */}
        <Route path="/" element={
          <ProtectedRoute>
            <Home />
          </ProtectedRoute>
        } />

        <Route path="/books" element={
          <ProtectedRoute>
            <BookList />
          </ProtectedRoute>
        } />

        <Route path="/book/:id" element={
          <ProtectedRoute>
            <BookDetail />
          </ProtectedRoute>
        } />

        <Route path="/cart" element={
          <ProtectedRoute>
            <Cart />
          </ProtectedRoute>
        } />

        <Route path="/checkout" element={
          <ProtectedRoute>
            <CheckoutPage />
          </ProtectedRoute>
        } />

        <Route path="/orders" element={
          <ProtectedRoute>
            <MyOrdersPage />
          </ProtectedRoute>
        } />

        <Route path="/profile" element={
          <ProtectedRoute>
            <ProfilePage />
          </ProtectedRoute>
        } />


        {/* Admin Protected Routes */}
        <Route path="/admin-dashboard" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminDashboard />
          </ProtectedRoute>
        } />

        <Route path="/admin-dashboard/orders"
          element={
            <ProtectedRoute requiredRole="ADMIN">
              <AdminOrdersPage />
            </ProtectedRoute>
          }
        />

        {/* Other Route */}
        <Route path="/api/auth" element={<Toggle />} />
      </Routes>
    </>
  );
}

function App() {
  return (
          <AuthProvider>
            <CartProvider>
              <Router>
                <AppContent />
              </Router>
            </CartProvider>
          </AuthProvider>

  );
}

export default App;
