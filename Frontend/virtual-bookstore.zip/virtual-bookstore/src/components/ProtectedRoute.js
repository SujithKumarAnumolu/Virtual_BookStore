import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const ProtectedRoute = ({ children, requiredRole }) => {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location, message: 'Please log in to access this page.' }}
      />
    );
  }

  if (requiredRole && user.role !== requiredRole) {
    return (
      <Navigate
        to="/"
        replace
        state={{ message: 'You do not have permission to access this page.' }}
      />
    );
  }

  return children;
};

export default ProtectedRoute;
