import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import './Navbar.css';

const Navbar = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { cartItems, resetCart } = useCart(); //to include resetCart

  const isAdmin = user?.role === 'admin';

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/books?query=${encodeURIComponent(searchTerm)}`);
      setSearchTerm('');
    }
  };

  const handleLogout = () => {
    logout();
    resetCart(); //for immediately clear cart from context
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <Link to="/">📚 Virtual Bookstore</Link>
      </div>

      <div className="navbar-right">
        <form className="navbar-search" onSubmit={handleSearch}>
          <input
            type="text"
            placeholder="Search books..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button type="submit">🔍</button>
        </form>

        <ul className="navbar-links">
          <li><Link to="/books">Books</Link></li>

          <li>
            <Link to="/cart">
              🛒 Cart
              {cartItems.length > 0 && (
                <span className="cart-badge">{cartItems.length}</span>
              )}
            </Link>
          </li>

          {isAdmin && (
            <li><Link to="/admin-dashboard">Admin Dashboard</Link></li>
          )}

          {user ? (
            <>
              <li className="user-dropdown">
                <span className="welcome-msg">👋 {user.name}</span>
                <ul className="dropdown-menu">
                  <li><Link to="/orders">My Orders</Link></li>
                  <li><Link to="/profile">Profile</Link></li>
                </ul>
              </li>
              <li><button onClick={handleLogout} className="logout-button">Logout</button></li>
            </>
          ) : (
            <>
              <li><Link to="/login" className="login-signup">Login</Link></li>
              <li><Link to="/signup" className="login-signup">Sign Up</Link></li>
            </>
          )}
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
