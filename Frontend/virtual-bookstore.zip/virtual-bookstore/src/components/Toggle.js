import React, { useState } from "react";
import Login from "../pages/Login"; // importing login
import SignUp from "../pages/Signup"; // importing signup
import './TogglePage.css'
const Toggle = () => {
  const [isLogin, setIsLogin] = useState(true); // it will toggle between login and signUp

  const toggleAuth = () => {
    setIsLogin(!isLogin); // Toggle the state
  };

  return (
    <div id= "toggle">
      {isLogin ? <Login /> : <SignUp />} {/* Conditionally render Login or SignUp */}
      <button  onClick={toggleAuth}>
        {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Log In"}
      </button>
    </div>
  );
};

export default Toggle;
