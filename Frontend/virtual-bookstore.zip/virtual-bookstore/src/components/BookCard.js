import React from 'react';
import { useNavigate } from 'react-router-dom';

const BookCard = ({ book }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/book/${book.id}`);
  };

  return (
    <div 
      onClick={handleClick}
      style={{
        border: '1px solid #ccc',
        borderRadius: '8px',
        padding: '16px',
        margin: '12px',
        width: '200px',
        cursor: 'pointer',
        boxShadow: '0 2px 5px rgba(0,0,0,0.1)'
      }}
    >
      <img 
        src={book.coverImageUrl || 'https://via.placeholder.com/150'} 
        alt={book.title} 
        style={{ width: '100%', height: '200px', objectFit: 'cover', marginBottom: '8px' }}
      />
      <h3 style={{ margin: '0 0 8px' }}>{book.title}</h3>
      <p style={{ fontStyle: 'italic', color: '#555' }}>{book.author}</p>
      <p style={{ fontWeight: 'bold' }}>${book.price}</p>
    </div>
  );
};

export default BookCard;
