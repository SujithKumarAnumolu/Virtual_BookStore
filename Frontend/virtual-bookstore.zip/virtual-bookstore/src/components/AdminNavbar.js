import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './AdminNavbar.css';

const AdminNavbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="admin-navbar">
      <div className="admin-navbar-logo">
        <Link to="/admin-dashboard">📚 Virtual Bookstore</Link>
      </div>

      <ul className="admin-navbar-links">
        <li><Link to="/admin-dashboard">Manage Books</Link></li>
        <li><Link to="/admin-dashboard/orders">Manage Orders</Link></li>
        <li className="admin-welcome-msg">👋 {user?.name}</li>
        <li><button onClick={handleLogout} className="admin-logout-button">Logout</button></li>
      </ul>
    </nav>
  );
};

export default AdminNavbar;
