package com.Spring.WebApp.Controller;

import com.Spring.WebApp.Model.Order;
import com.Spring.WebApp.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:3000")  // Allow's React Frontend
public class OrderController {

    @Autowired
    private OrderService orderService;

    // To Place Order
    @PostMapping
    public ResponseEntity<Order> placeOrder(@RequestBody Order order) {
        Order savedOrder = orderService.saveOrder(order);
        return ResponseEntity.ok(savedOrder);
    }

    // To Get all orders (Admin)
    @GetMapping
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    // To Get orders by user email
    @GetMapping("/user/{email}")
    public List<Order> getOrdersByUserEmail(@PathVariable String email) {
        return orderService.getOrdersByUserEmail(email);
    }

    // To Update order status
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateOrderStatus(@PathVariable Long id, @RequestBody String status) {
        Order updatedOrder = orderService.updateOrderStatus(id, status.replace("\"", ""));
        return ResponseEntity.ok(updatedOrder);
    }
}
