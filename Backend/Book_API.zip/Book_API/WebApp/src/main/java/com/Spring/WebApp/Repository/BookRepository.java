package com.Spring.WebApp.Repository;

import com.Spring.WebApp.Model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {
    List<Book> findByTitleContainingIgnoreCase(String title);
    List<Book> findByGenreIgnoreCase(String genre); // Case-insensitive for genre match
}


