package com.Spring.WebApp.Controller;

import com.Spring.WebApp.Model.Book;
import com.Spring.WebApp.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/books")
@CrossOrigin(origins = "http://localhost:3000") // Allow's React frontend
public class BookController {

    @Autowired
    private BookRepository bookRepository;

    // Fetch books by genre (used on HomePage)
    @GetMapping("/genre/{genre}")
    public List<Book> getBooksByGenre(@PathVariable String genre) {
        return bookRepository.findByGenreIgnoreCase(genre);
    }

    //To Get all books
    @GetMapping
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    // To Add new book
    @PostMapping
    public ResponseEntity<?> addBook(@RequestBody Book book) {
        bookRepository.save(book);
        return ResponseEntity.ok("Book added successfully!");
    }

    // To Update an existing book
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBook(@PathVariable Integer id, @RequestBody Book bookDetails) {
        return bookRepository.findById(id)
                .map(book -> {
                    book.setTitle(bookDetails.getTitle());
                    book.setAuthor(bookDetails.getAuthor());
                    book.setDescription(bookDetails.getDescription());
                    book.setPrice(bookDetails.getPrice());
                    book.setStock(bookDetails.getStock());
                    book.setGenre(bookDetails.getGenre());
                    book.setImageUrl(bookDetails.getImageUrl());
                    book.setAvailable(bookDetails.isAvailable());
                    bookRepository.save(book);
                    return ResponseEntity.ok("Book updated successfully!");
                })
                .orElse(ResponseEntity.badRequest().body("Book not found"));
    }

    // To Delete book
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable Integer id) {
        if (!bookRepository.existsById(id)) {
            return ResponseEntity.badRequest().body("Book not found");
        }
        bookRepository.deleteById(id);
        return ResponseEntity.ok("Book deleted successfully!");
    }
}
