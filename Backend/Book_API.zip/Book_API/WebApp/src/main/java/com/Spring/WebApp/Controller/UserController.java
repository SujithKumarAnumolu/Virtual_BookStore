//UserController
package com.Spring.WebApp.Controller;


import com.Spring.WebApp.Model.Users;
import com.Spring.WebApp.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000") // Allow's React Frontend
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // To Login

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Users loginRequest) {
        String email = loginRequest.getEmail();
        String rawPassword = loginRequest.getPassword();
        String role = loginRequest.getRole();
        if (!role.equals("USER") && !role.equals("ADMIN")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid role specified.");
        }

        Optional<Users> userOpt = userRepository.findByEmailAndRole(email, role);

        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found with provided role.");
        }

        Users user = userOpt.get();

        if (!passwordEncoder.matches(rawPassword, user.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect password.");
        }

        // Ensure role in DB matches the request role (extra safety)
        if (!user.getRole().equals(role)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Role mismatch.");
        }

        return ResponseEntity.ok(user);
    }


    // To SignUp
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Users newUser) {
        // To Check if email already exists
        Optional<Users> existingUser = userRepository.findByEmailAndRole(newUser.getEmail(), newUser.getRole());
        if (existingUser.isPresent()) {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body("User with this email and role already exists.");
        }

        // To check the basic validation
        if (newUser.getEmail() == null || newUser.getPassword() == null || newUser.getName() == null) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("Missing required fields: name, email, or password.");
        }

        // To Encode password before saving
        newUser.setPassword(passwordEncoder.encode(newUser.getPassword()));

        // To Savethe new user to database
        userRepository.save(newUser);

        return ResponseEntity.ok("Registration successful");
    }

    @PutMapping("/update-profile")
    public ResponseEntity<?> updateProfile(@RequestBody Users updatedUser) {
        Optional<Users> userOpt = userRepository.findByEmailAndRole(updatedUser.getEmail(), updatedUser.getRole());
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found.");
        }

        Users user = userOpt.get();

        // To update the name
        user.setName(updatedUser.getName());

        // To update the password only if not empty
        if (updatedUser.getPassword() != null && !updatedUser.getPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(updatedUser.getPassword()));
        }
        user.setAddress(updatedUser.getAddress());

        userRepository.save(user);

        return ResponseEntity.ok("Profile updated successfully.");
    }

}


