package com.Spring.WebApp.Controller;

import com.Spring.WebApp.Model.Book;
import com.Spring.WebApp.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class PublicBookController {

    @Autowired
    private BookRepository bookRepository;

    //To Get all books (for home page or listings)
    @GetMapping
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    //To Get single book by ID
    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Integer id) {
        return bookRepository.findById(id).orElse(null);
    }

    // To Search by title
    @GetMapping("/search")
    public List<Book> searchByTitle(@RequestParam("title") String title) {
        return bookRepository.findByTitleContainingIgnoreCase(title);
    }

    // To Get books by genre (case-insensitive)
    @GetMapping("/genre/{genre}")
    public List<Book> getBooksByGenre(@PathVariable String genre) {
        return bookRepository.findByGenreIgnoreCase(genre);
    }

}
